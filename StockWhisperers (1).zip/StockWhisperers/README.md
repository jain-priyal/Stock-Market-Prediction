# Stock Whisperers

## Stock Market Prediction Using Sentiment Analysis of News Articles

## Team Members

Neeraj Mirashi (z5316619) 
Priyal Jain (z5512958) 
Mark Wang (z5429626) 
Reynah Hsu (z5245032) 
